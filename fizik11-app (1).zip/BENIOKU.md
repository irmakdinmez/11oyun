# 11. Sınıf Fizik Oyunu — Uygulama paketi

Bu klasör, oyunun telefona kurulabilen uygulama (PWA) sürümüdür. İnternetsiz de çalışır, ana ekrana simgeyle eklenir, Android'de geri tuşu ekranlar arasında geri gider. Google Play'e de bu klasörden yüklenir.

## Klasörde neler var

| Dosya | Ne işe yarar |
|---|---|
| `index.html` | Oyunun kendisi (2500 soru, tüm çizimler içinde) |
| `manifest.webmanifest` | Uygulamanın adı, simgesi, rengi |
| `sw.js` | İnternetsiz çalışmayı sağlar |
| `icons/` | Uygulama simgeleri (192, 512, maskable, Apple) |
| `fonts/` | Calibri benzeri Carlito yazı tipi (SIL Open Font License) |
| `gizlilik.html` | Google Play'in istediği gizlilik politikası |
| `.nojekyll` | GitHub Pages için gerekli boş dosya |

## 1. Adım — İnternete koy (GitHub Pages)

1. github.com'da yeni bir **public** depo aç (ör. `fizik11`).
2. **Add file → Upload files** ile bu klasördeki **tüm dosyaları ve klasörleri** yükle (zip'i değil, içindekileri). `index.html` deponun en üstünde olmalı.
3. **Settings → Pages → Branch: main / (root) → Save**.
4. 1–2 dakika sonra oyun şu adreste açılır: `https://KULLANICIADIN.github.io/fizik11/`

Telefonda bu adresi Chrome ile aç → menü → **Ana ekrana ekle / Uygulamayı yükle**. Artık uygulama gibi açılır ve internetsiz de çalışır.

## 2. Adım — Android uygulama dosyası üret (PWABuilder)

1. **pwabuilder.com** adresine gir, oyunun adresini yapıştır → **Start**.
2. Puan ekranında manifest ve service worker yeşil görünmeli → **Package for stores → Android → Generate Package**.
3. Paket adı (Package ID) örneği: `io.github.kullaniciadin.fizik11`. Uygulama adı: `11. Sınıf Fizik Oyunu`.
4. İndirilen zip'te şunlar olur: `.aab` (Play'e yüklenecek dosya), `.apk` (telefonda denemek için), **signing.keystore** ve şifre bilgileri. **Keystore dosyasını ve şifreleri kaybetme**; güncelleme yayınlamak için hep aynısı gerekir.
5. Zip'teki `assetlinks.json` dosyasını GitHub deposunda `.well-known/assetlinks.json` yoluna yükle. Bu, uygulamanın üstünde tarayıcı adres çubuğu görünmemesini sağlar.

## 3. Adım — Google Play'e yükle

1. **play.google.com/console** → geliştirici hesabı aç (tek seferlik ücret).
2. **Uygulama oluştur** → ad, dil (Türkçe), "Oyun" ya da "Uygulama", ücretsiz.
3. **Dahili test** kanalına `.aab` dosyasını yükle, önce kendi telefonunda dene.
4. Mağaza kaydı: kısa ve uzun açıklama, 512×512 simge (`icons/icon-512.png`), en az 2 ekran görüntüsü, 1024×500 öne çıkan görsel.
5. **Uygulama içeriği** bölümünde: gizlilik politikası adresi (`https://KULLANICIADIN.github.io/fizik11/gizlilik.html`), reklam yok, veri toplama yok, hedef yaş grubu.
6. Hepsi tamamlanınca **Üretim → Yeni sürüm → İncelemeye gönder**. İnceleme genellikle birkaç gün sürer.

> Not: Yeni açılan kişisel geliştirici hesaplarında Google, üretime çıkmadan önce bir süre kapalı test (belirli sayıda test kullanıcısı) isteyebilir. Play Console'daki güncel koşulları kontrol et.

## Oyunu güncellemek

1. GitHub'da yeni `index.html` dosyasını eskisinin üstüne yükle.
2. `sw.js` içindeki `fizik11-v1` yazısını `fizik11-v2` yap (her güncellemede bir artır) ve yükle. Böylece telefonlardaki eski sürüm yenilenir.
3. Play sürümü web adresini açtığı için çoğu güncellemede Play'e yeni dosya yüklemen gerekmez; ad veya simge değişirse PWABuilder'dan aynı keystore ile yeni `.aab` üretip yükle.
