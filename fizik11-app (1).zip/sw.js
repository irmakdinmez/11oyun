// Oyunun internetsiz de açılmasını sağlar. Oyunu her güncellediğinde aşağıdaki sürüm numarasını artır (v1 → v2 ...).
const CACHE = "fizik11-v2";
const FILES = ["./", "index.html", "gizlilik.html", "manifest.webmanifest",
  "fonts/Carlito-Regular.woff", "fonts/Carlito-Bold.woff",
  "icons/icon-192.png", "icons/icon-512.png", "icons/maskable-192.png", "icons/maskable-512.png",
  "icons/apple-touch-icon.png", "icons/favicon.png"];
self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
// Önce önbellek (hızlı açılış), arkada ağdan yeni sürümü al.
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  e.respondWith(caches.match(e.request, {ignoreSearch:true}).then(hit => {
    const net = fetch(e.request).then(res => {
      if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); }
      return res;
    }).catch(() => hit || caches.match("index.html"));
    return hit || net;
  }));
});
